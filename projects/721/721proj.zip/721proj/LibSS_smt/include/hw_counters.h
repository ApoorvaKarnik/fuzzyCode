#define	hw_counter_CYCLE	0
#define	hw_counter_INSTR	1
