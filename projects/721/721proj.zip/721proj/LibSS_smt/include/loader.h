#ifndef LOADER_H
#define LOADER_H

extern int ld_target_big_endian;

#endif /* LOADER_H */
