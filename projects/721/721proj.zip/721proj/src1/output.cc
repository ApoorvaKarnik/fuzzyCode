#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "Thread.h"
#include "info.h"

extern SS_TIME_TYPE SKIP_AMT;


/* set to non-zero when simulator should dump statistics */
int sim_dump_stats = FALSE;

void
sim_stats(FILE *stream)
{
  extern time_t start_time;
  time_t elapsed = MAX(time((time_t *)NULL) - start_time, 1);

  INFO("sim: simulation time: %s (%f insts/sec)",
       elapsed_time(elapsed), (double)THREAD[0]->num_insn/(double)elapsed);

  char buf[100];
  INFO("sim: number of instructions: %s",
  			comma(THREAD[0]->num_insn, buf, 100));
  INFO("sim: number of instructions *after skip amount*: %s",
  			comma(THREAD[0]->num_insn - SKIP_AMT, buf, 100));

  //INFO("sim: number of instructions: %.0f", (double)THREAD[0]->num_insn);
  //INFO("sim: number of instructions *after skip amount*: %.0f", (double)(THREAD[0]->num_insn - SKIP_AMT));

}
