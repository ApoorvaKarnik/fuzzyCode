#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Thread.h"
#include "info.h"
#include "bpred_wrapper.h"
#include "parameters.h"



SS_TIME_TYPE SKIP_AMT = (SS_TIME_TYPE) 0;

void trace_consume_init() {
   db_t *db_ptr;

   char buf[100];
   INFO("SKIPPING TO %s ...", comma(SKIP_AMT, buf, 100));
   //INFO("SKIPPING TO %.0f ...", (double)SKIP_AMT);
   for (SS_TIME_TYPE i = 0; i < SKIP_AMT; i++) {
        db_ptr = THREAD[0]->get_instr();
        if (db_ptr->a_flags & F_TRAP) {
           THREAD[0]->trap_now(db_ptr->a_inst);
           THREAD[0]->trap_resume();
        }
   }
   INFO("DONE SKIPPING.");
}	// trace_consume_init()


void trace_consume() {


  ////////////////////////////////
  // Main simulator loop.
  ////////////////////////////////
  while (1) {

  }
}	// trace_consume()
