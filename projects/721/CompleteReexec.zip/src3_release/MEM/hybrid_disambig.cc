#include "hybrid_disambig.h"

void hybrid_disambig::updatePrediction(unsigned int pc, unsigned int distance, bool collide){
  
 it = memPred.find(pc) ;
 
 storeDist[pc] = distance; // currently writting only one distance

 if( it == memPred.end()){

     if(collide){

      memPred[pc] = 2; // Not seen till now and was collided
			// definately make it "2" so that it stalls next time.    
     }else{
      memPred[pc] = 1; // This is sort of imp. This is because, it is not in table and it was
			//  did not collide then next time it should be in not stall
			//  but also not "0" so that it could change its mind
     }

 }else{

     if(collide){
      	if(memPred[pc]<3)
      		memPred[pc]++;
     }
     else{
      	if(memPred[pc]>0)
      		memPred[pc]--;
     }
 }

 return;

}

 bool  hybrid_disambig::getPrediction(  unsigned int pc, 
					unsigned int distance){

 unsigned int value;
 bool found = true;

 it = storeDist.find(pc);

 if(it == storeDist.end()){
 	
	found = false;

 }else{

  if((*it).second == distance)
	found = true;
  else
	found = false; 
}
// remove this
//return found;	

 it = memPred.find(pc) ;

 if( it == memPred.end()){

   assert(found==false && "should not have found in store set");
   return true; // If not found speculate colliding : STALL

 }else{
   
   value = memPred[pc];
   assert(value <= 3 && "Memory prediction counter exceeded limit");
   if(value<=1){ // If found then do as decision : DONT STALL
	
	//return false;
	return found?true:false;
	// In this case -- Consider the case
	// A load is/was never dependent on prev stores
	// occuring consistently its counter became 0
	// Now --first collision occurs..the counter is now
	// 1 therefore if the load re-appears again..it wont stall
	// I want it to stall !! coz I think that it can re-show its dependence
	// therefore this time Lets stall it. 

   }else{
	return true; // STALL IN THIS CASE
  }

 }

}

void hybrid_disambig::count_load_addr_freq(unsigned int load_addr){
/* it = memTable.find(load_addr); 
 if( it == memTable.end()){
     this->memTable[load_addr] = 1;
 }else{
     memTable[load_addr]++;
 }*/
  return;
}

void hybrid_disambig::count_load_pc_freq(unsigned int pc){
/* it = pcTable.find(pc) ;
 if( it == pcTable.end()){
     this->pcTable[pc] = 1;
 }else{
     pcTable[pc]++;
 }*/
  return;
}

void hybrid_disambig::stat(){

ofstream loadFile1;
ofstream pcFile1;
ofstream pcFile2;
/*
 loadFile1.open("LoadData1.dat");
if(!loadFile1){
 cout<<"cant open file"<<endl;
return;
}
 pcFile1.open("pcData1.dat");
if(!pcFile1){
 cout<<"cant open file"<<endl;
return;
}
*/
 pcFile2.open("Table.dat");
if(!pcFile2){
 cout<<"cant open file"<<endl;
return;
}
/*
	for ( it=memTable.begin() ; it != memTable.end(); it++ ){
         
         if(loadFile1 != NULL){
           if(loadFile1.good())
    	   loadFile1 << (*it).first << " " << (*it).second << endl;
           loadFile1.flush();
         }
        }
         loadFile1.close();

	for ( it=pcTable.begin() ; it != pcTable.end(); it++ ){
         if(pcFile1 != NULL){
           if(pcFile1.good())
    	   pcFile1 << (*it).first << " " << (*it).second << endl;
           pcFile1.flush();
          }
         }
          pcFile1.close();
*/
	for ( it=memPred.begin() ; it != memPred.end(); it++ ){
         if(pcFile2 != NULL){
           if(pcFile2.good())
    	   pcFile2 << (*it).first << " " << (*it).second << endl;
           pcFile2.flush();
          }
         }
          pcFile2.close();

	return;
}

