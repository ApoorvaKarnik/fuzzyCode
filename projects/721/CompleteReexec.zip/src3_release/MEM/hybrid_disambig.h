#ifndef MY_HEADER_FILE
#define MY_HEADER_FILE
#include <map>
#include <iostream>
#include <fstream>
#include <assert.h>
//#include <ofstream>
using namespace std;
class hybrid_disambig {
private:
 ofstream loadFile, pcFile;
 map<unsigned int, unsigned int> memTable;
 map<unsigned int, unsigned int> memPred;
 map<unsigned int, unsigned int> storeDist;
 map<unsigned int, unsigned int> pcTable;
 map<unsigned int, unsigned int>::iterator it;
public:
 //hybrid_disambig();
 void updatePrediction(unsigned int pc, unsigned int distance, bool collide);
 bool getPrediction(unsigned int pc, unsigned int distance);
 void count_load_pc_freq(unsigned int pc);
 void count_load_addr_freq(unsigned int pc);
 void stat();

};
#endif
