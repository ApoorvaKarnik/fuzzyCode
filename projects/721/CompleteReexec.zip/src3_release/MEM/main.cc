#include "hybrid_disambig.h"
using namespace std;

int main () {
  hybrid_disambig dis;
for(int i=999990; i>=0;i--){
 dis.count_load_addr_freq(89+i);
 dis.count_load_addr_freq(89*i);
 dis.count_load_addr_freq(200-i);
 dis.count_load_addr_freq(230);
 dis.count_load_pc_freq(43);
 dis.count_load_pc_freq(93);}
 dis.stat();
  ofstream myfile;
  myfile.open ("example.txt");
  myfile << "Writing this to a file.\n";
  myfile.close();
  return 0;
}
