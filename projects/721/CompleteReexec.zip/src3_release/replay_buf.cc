#include "replay_buf.h"
#include "processor.h"


replay_buf::replay_buf(unsigned int rob_size) {

	replay_buf::head = replay_buf::tail = replay_buf::index = 0;
	replay_buf::head_phase = replay_buf::tail_phase = replay_buf::index_phase = 0;
	replay_buf::current_length = 0;	   
	replay_buf::buf_size = rob_size;
	replay_buf::has_reissuable = false;
  	replay_buf::buf = (rep_entry *)calloc(rob_size, sizeof(rep_entry));
	for(unsigned int i=0; i < rob_size ; i++)
		replay_buf::buf[i].valid = false;
}

bool replay_buf::stall(unsigned int width){
        //cout<<"Request for "<< width << " have only " << (buf_size - current_length)<<endl;
	return ((width <= (buf_size - current_length))?false:true);
}

void replay_buf::dispatch(unsigned int index, unsigned long long br_mask, unsigned int al_ind_int, unsigned int al_ind_fp, 
			 unsigned int &rb_tail, bool &rb_tail_phase){

	buf[tail].valid 	= true;
	buf[tail].speculate 	= false;
	buf[tail].pay_index 	= index;
	buf[tail].branch_mask 	= br_mask;
	buf[tail].al_index_int 	= al_ind_int;
	buf[tail].al_index_fp 	= al_ind_fp;
	buf[tail].reexecute 	= false;
	
//    cout<<"Dispatched index "<< index <<endl;
	current_length++;	

	
	assert(al_ind_int == tail && " This is where it goes wrong");
  //  cout<<"al index "<<al_ind_int<<" rb_tail "<<tail<<endl;	
 
	tail = MOD_S( tail+1 , buf_size );

	
	if (tail == 0)
	      tail_phase = !tail_phase;

	rb_tail = tail;
	rb_tail_phase = tail_phase;

	
}

void replay_buf::commit_head(){
	
	buf[head].valid 	= false;
	buf[head].speculate 	= false;
	buf[head].pay_index 	= 0;
	buf[head].branch_mask 	= 0;
	buf[head].al_index_int 	= 0;
	buf[head].al_index_fp 	= 0;
	buf[head].reexecute 	= false;
	
	current_length--;	
	
	head = MOD_S( head+1 , buf_size );
	
	if (head == 0)
	      head_phase = !head_phase;
	
}

unsigned int replay_buf::get_for_re_issue(bool &next, unsigned int &ind){
	unsigned int pay_index;

	next = false;
	if(index == tail && index_phase == tail_phase){
		has_reissuable = false;
		ind = tail;
        buf[index].reexecute = false;
		//assert(buf[index].reexecute == false && "reached tail");	
		return 0;	
	}
	
    next = true;
	pay_index = buf[index].pay_index;
	
	assert(buf[index].reexecute == true && "How ?? not true");	
	buf[index].reexecute = false;
	ind = index; 
	
	index = MOD_S( index +1  , buf_size );
	
	if (index == 0)
	      index_phase = !index_phase;
	
	return pay_index;
}

unsigned int replay_buf::get_length(){
	return current_length;
}

unsigned int replay_buf::get_tail(){
	return tail;
}

void replay_buf::set_reissue(){
 
	index = head;
	index_phase = head_phase;	
	has_reissuable = true;
    for (unsigned int i = 0, j = head; i < current_length; i++, j = MOD_S((j+1), buf_size)){
    assert(buf[j].valid==true && "is this possible");  
	buf[j].reexecute = true;}
	return; 
}

void replay_buf::squash(){

//	index = head;
//	index_phase = head_phase;	
	replay_buf::head = replay_buf::tail = replay_buf::index = 0;
	replay_buf::head_phase = replay_buf::tail_phase = replay_buf::index_phase = 0;
	replay_buf::current_length = 0;	   
	replay_buf::has_reissuable = false;
	for(unsigned int i=0; i < buf_size ; i++){
		//cout<<"squashing "<<buf[i].pay_index<<endl;
		replay_buf::buf[i].valid = false;}

}

void replay_buf::checkpoint(unsigned int& chkpt_tail, bool& chkpt_tail_phase ) {

   chkpt_tail = tail;
   chkpt_tail_phase = tail_phase;

}

void replay_buf::clear_reissue(){
	has_reissuable = false;
}


void replay_buf::restore(unsigned int recover_tail, bool recover_tail_phase ) {
   /////////////////////////////
   // Restore LQ.
   /////////////////////////////
//	index = head;
//	index_phase = head_phase;	
   // Restore tail state.
   tail = recover_tail;
   tail_phase = recover_tail_phase;

   current_length = MOD_S((buf_size + tail - head), buf_size);
   if ((current_length == 0) && (tail_phase != head_phase))
      current_length = buf_size;
assert(current_length == 1);

   for (unsigned int i = 0; i < buf_size; i++){
      buf[i].valid = false;}

   for (unsigned int i = 0, j = head; i < current_length; i++, j = MOD_S((j+1), buf_size)){
      buf[j].valid = true;}
   //cout<<"New tail "<< tail <<endl; 
}
