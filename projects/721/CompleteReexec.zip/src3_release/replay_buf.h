#ifndef _REPLAY_BUF_H_
#define _REPLAY_BUF_H_


typedef struct replay_entry{
	bool                valid;
	unsigned int        pay_index;
	bool                speculate;
   	unsigned long long  branch_mask;	// branches that this instruction depends on
	unsigned int        al_index_int;
	unsigned int        al_index_fp;
	bool                reexecute;
} rep_entry;

class replay_buf {

   unsigned int head;
   bool head_phase;
   unsigned int tail;
   bool tail_phase;
   unsigned int index;
   bool index_phase;
   unsigned int current_length;
   bool has_reissuable;

   unsigned int chkpt_tail;
   unsigned int chkpt_tail_phase;
	
public:
   rep_entry *buf;

   unsigned int buf_size;

   replay_buf(unsigned int size);			// constructor
   
   bool stall(unsigned int width);

   void dispatch(unsigned int index, unsigned long long br_mask, unsigned int al_ind_int, unsigned int al_ind_fp, 
			 unsigned int &rb_tail, bool &rb_tail_phase);
   void commit_head();

   unsigned int get_length();
	
   unsigned int get_tail();
   unsigned int get_size(){ return buf_size;}
   unsigned int get_head(){ return head; }
   unsigned int get_index(){ return index; }
   unsigned int get_head_index() { return buf[head].pay_index; }
   
   unsigned int get_for_re_issue(bool &next, unsigned int &ind); 

   bool reissue(){return has_reissuable; } 
 
   void set_reissue();
   void clear_reissue();
   void squash(); 
   void checkpoint(unsigned int& chkpt_tail, bool& chkpt_tail_phase );
   void restore(unsigned int recover_tail, bool recover_tail_phase );	 
	
};
#endif
