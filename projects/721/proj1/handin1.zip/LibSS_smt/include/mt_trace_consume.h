void trace_consume_init();
void trace_consume();
