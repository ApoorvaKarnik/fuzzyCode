extern bool bpred_wrapper(db_t *db_ptr);
