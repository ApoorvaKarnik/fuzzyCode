#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "Thread.h"
#include "info.h"

extern SS_TIME_TYPE SKIP_AMT;

int askValue(int);
/* set to non-zero when simulator should dump statistics */
int sim_dump_stats = FALSE;

void
sim_stats(FILE *stream)
{
  extern time_t start_time;
  time_t elapsed = MAX(time((time_t *)NULL) - start_time, 1);

  INFO("sim: simulation time: %s (%f insts/sec)",
       elapsed_time(elapsed), (double)THREAD[0]->num_insn/(double)elapsed);

  char buf[100];
  INFO("sim: number of instructions: %s",
  			comma(THREAD[0]->num_insn, buf, 100));
  INFO("sim: number of instructions *after skip amount*: %s",
  			comma(THREAD[0]->num_insn - SKIP_AMT, buf, 100));

  INFO("control = %d",askValue(1)); 
  INFO("calls = %d",askValue(2)); 
  INFO("returns = %d",askValue(12)); 
  INFO("loads  = %d",askValue(3)); 
  INFO("stores = %d",askValue(4)); 
  INFO("PC of 9,900th instruction encountered = 0x%x",askValue(5)); 
  INFO("address of third LOAD encountered = 0x%x",askValue(6)); 
  INFO("address of third STORE encountered = 0x%x",askValue(7)); 
  INFO("not-taken conditional branches = %d",askValue(8)); 
  INFO("taken conditional branches = %d",askValue(9));
  INFO("ILP limit study: INSTRUCTIONS = %ld",askValue(11)); 
  INFO("ILP limit study: CYCLES = %ld",askValue(10)); 
  INFO("ILP limit study: IPC = %0.2lf",(float)askValue(11)/askValue(10)); 
 //INFO("sim: number of instructions: %.0f", (double)THREAD[0]->num_insn);
  //INFO("sim: number of instructions *after skip amount*: %.0f", (double)(THREAD[0]->num_insn - SKIP_AMT));

}
