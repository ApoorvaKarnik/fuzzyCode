#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>
#include <time.h>
#include "Thread.h"
#include "info.h"
#include "bpred_wrapper.h"
#include "parameters.h"
#include "mt.h"
#include <map>
#include <algorithm>
#include <string.h>
using namespace std;

SS_TIME_TYPE SKIP_AMT = (SS_TIME_TYPE) 0;

int cond = 0;
int instOpcode;
int firstSourceReg;
int a_prev = 0;	
int cond_flag = 0;
unsigned long int insCount = 0;
unsigned int i,j;
bool branch;
long int misPred=0;	
long int temp=0;
int regTs[TOTAL_ARCH_REGS];		
map<unsigned int,long int> memMap;


	
int  cntrlInst=0;
int callInst=0;
int retInst=0;
int loadInst=0;
int storeInst=0;
unsigned long int pc=0;
unsigned long int memAddrThirdLoadInst=0;
unsigned long int memAddrThirdStoreInst=0;
unsigned long int notTakenCondBr=0;
unsigned long int takenCondBr=0;
int maxCycle=0;
int totalInst=0;

void trace_consume_init() {
   db_t *db_ptr;

   char buf[100];
   INFO("SKIPPING TO %s ...", comma(SKIP_AMT, buf, 100));
   //INFO("SKIPPING TO %.0f ...", (double)SKIP_AMT);
   for (SS_TIME_TYPE i = 0; i < SKIP_AMT; i++) {
        db_ptr = THREAD[0]->get_instr();
        if (db_ptr->a_flags & F_TRAP) {
           THREAD[0]->trap_now(db_ptr->a_inst);
           THREAD[0]->trap_resume();
        }
   }
	

   INFO("DONE SKIPPING.");
}	// trace_consume_init()

extern unsigned long int askValue(int ask){

switch(ask){

case 1: return cntrlInst;
case 2: return callInst;
case 3: return loadInst;
case 4: return storeInst;
case 5: return pc;
case 6: return memAddrThirdLoadInst;
case 7: return memAddrThirdStoreInst;
case 8: return notTakenCondBr;
case 9: return takenCondBr;
case 10: return maxCycle;
case 11: return insCount;
case 12: return retInst;
default: return 0;
}

}

void trace_consume() {


  ////////////////////////////////
  // Main simulator loop.
  ////////////////////////////////
  
  SS_INST_TYPE inst;
	
  memset(regTs, 0, TOTAL_ARCH_REGS*sizeof(int));	

  int align=0;

  while (1) {
	
	totalInst++;
	branch = false;
	db_t *db_ptr = THREAD[0]->get_instr();   
	insCount += 1;
	if(insCount==9900){
		pc=db_ptr->a_pc;
	}

	if (db_ptr->a_flags & F_TRAP) {
		//printf("This is a system call\n");
		THREAD[0]->trap_now(db_ptr->a_inst);
		THREAD[0]->trap_resume();
	}

	inst.a = db_ptr->a_inst.a; // OPCODE PART OF INSTRUCTION
	inst.b = db_ptr->a_inst.b;
	
	instOpcode=SS_OPCODE(inst);
	firstSourceReg=RS;

	if(instOpcode==JAL){
		callInst++;	
	}
	
	if(instOpcode==JALR){
		callInst++;	
	}
	if(firstSourceReg==31){
		retInst++;
	}

	if (db_ptr->a_flags & F_CTRL) {
		cntrlInst++;
		if(PERFECT_BRANCH_PREDICTION==false){
		branch=bpred_wrapper(db_ptr);}
	}
	if (db_ptr->a_flags & F_COND) {
		cond++;
		if(db_ptr->a_next_pc != (db_ptr->a_pc+8)){
			takenCondBr++;
		}else{
			notTakenCondBr++;
		}

	}
	if (db_ptr->a_flags & F_LOAD) {
		loadInst++;
		if(loadInst==3){
			memAddrThirdLoadInst = db_ptr->a_addr;
		}
	}
	if (db_ptr->a_flags & F_STORE) {
		storeInst++;
		if(storeInst==3){	
			memAddrThirdStoreInst = db_ptr->a_addr;
		}
	}
	

		align=0;
		temp=0;
		for(i=0; i<db_ptr->a_num_rsrc ;i++){
			if(temp<regTs[db_ptr->a_rsrc[i].n])
			    temp=regTs[db_ptr->a_rsrc[i].n];
		}
	 	for(i=0; i<db_ptr->a_num_rsrcA ;i++){
                	if(temp<regTs[db_ptr->a_rsrcA[i].n])
        	            temp=regTs[db_ptr->a_rsrcA[i].n];
		}
		
		if(temp<misPred){
			temp=misPred;
		}
		if(branch==true){		 
			misPred=temp+1;
		}

	
	if(instOpcode==LB || instOpcode==LB_RR || instOpcode==LBU || instOpcode==LBU_RR ){
		if(memMap.find((db_ptr->a_addr )) != memMap.end()){
              		temp=max(memMap[db_ptr->a_addr],temp);
		}
	}

	if(instOpcode==LH || instOpcode==LH_RR || instOpcode==LHU || instOpcode==LHU_RR ){			
		align=1;				
			for(i=0 ; i<2;i++){
				if(memMap.find((db_ptr->a_addr & ~(align))+i) != memMap.end()){
   	           	 	temp=max(memMap[(db_ptr->a_addr & ~(align))+i],temp);}
			}		
	}

	if(instOpcode==LWL || instOpcode==LWR || instOpcode==LW || instOpcode==LW_RR || instOpcode==L_S || instOpcode==L_S_RR){
		align=3;				
			for(i=0 ; i<4;i++){
			if(memMap.find((db_ptr->a_addr & ~(align))+i) != memMap.end()){
   	        	       if(temp<memMap[(db_ptr->a_addr & ~(align))+i])
   	           	 	temp=memMap[(db_ptr->a_addr & ~(align))+i];}}			
						
	}

	if(instOpcode==DLW || instOpcode==DLW_RR ||instOpcode==L_D ||instOpcode==L_D_RR){		
		align=7;				
				for(i=0 ; i<8;i++){
				if(memMap.find((db_ptr->a_addr & ~(align))+i) != memMap.end()){
   	        	       if(temp<memMap[(db_ptr->a_addr & ~(align))+i])
   	           	 	temp=memMap[(db_ptr->a_addr & ~(align))+i];}}		
	}

	//NOW FOR STORES
	
	if(instOpcode==SB || instOpcode==SB_RR ){
		memMap[(db_ptr->a_addr )]=temp+1;	
	}
	if(instOpcode==SH || instOpcode==SH_RR ){
		align=1;				
		memMap[(db_ptr->a_addr & ~(align))]=temp+1;
		memMap[(db_ptr->a_addr & ~(align))+1]=temp+1;

	}
	if(instOpcode==SWL || instOpcode==SWR || instOpcode==SW || instOpcode==SW_RR || instOpcode==S_S || instOpcode==S_S_RR ){
		align=3;				
		memMap[(db_ptr->a_addr & ~(align))]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+1)]=temp+1;	
		memMap[((db_ptr->a_addr & ~(align))+2)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+3)]=temp+1;	
	
	}
	if(instOpcode==DSW || instOpcode==DSW_RR || instOpcode==S_D|| instOpcode==S_D_RR || instOpcode==DSZ || instOpcode==DSZ_RR ){
		align=7;				
		
		memMap[((db_ptr->a_addr & ~(align)))]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+1)]=temp+1;	
		memMap[((db_ptr->a_addr & ~(align))+2)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+3)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+4)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+5)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+6)]=temp+1;
		memMap[((db_ptr->a_addr & ~(align))+7)]=temp+1;
	 }

                for(i=0; i<db_ptr->a_num_rdst ;i++){
		if(db_ptr->a_rdst[i].n !=0)
                         regTs[db_ptr->a_rdst[i].n]=temp+1;}
		
	
		if(maxCycle<(temp))
                maxCycle=temp;

 }
}	// tirace_consume()
