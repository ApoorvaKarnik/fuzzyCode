#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <iostream>
#include <math.h>
#include "renamer.h"
#define DEB 0
using namespace std;
	
renamer::renamer(unsigned int n_log_regs,
		unsigned int n_phys_regs,
		unsigned int n_branches){
		renamer::cntr=0;
		renamer::totalArchRegs = n_log_regs;
		renamer::totalPhyRegs = n_phys_regs;
		renamer::maxBranches = n_branches;
		//cout<<" total arch reg "<<totalArchRegs<<" phy regs  "<<totalPhyRegs<<endl;	
		assert(n_phys_regs > n_log_regs);
		assert(64 >= n_branches);
		assert(n_branches >= 1);
		//RMT
		// Declaring and assiging the first 0..to ARCH_REGS PRF's to RMT
		renamer::AMT= new unsigned int[n_log_regs];
		renamer::RMT= new unsigned int[n_log_regs];
		for(unsigned int i=0;i<n_log_regs;i++){
			renamer::RMT[i]=i;
			renamer::AMT[i]=i;
		}
		//FREE LIST
		// May be this not the way to intialize
		renamer::f_list.tail= 0;
		renamer::f_list.head=0;
		renamer::f_list.currSize=n_phys_regs - n_log_regs;
		renamer::f_list.ele= new unsigned int[n_phys_regs - n_log_regs];	
		for(unsigned int i=0; i<(n_phys_regs - n_log_regs); i++){
			renamer::f_list.ele[i] = i + n_log_regs;
		}			
		//ACTIVE LIST
		renamer::act_list.tail=0;
		renamer::act_list.head=0;
		renamer::act_list.currSize = n_phys_regs-n_log_regs;
		renamer::act_list.inst= new PROP[n_phys_regs - n_log_regs];
		for(unsigned int i=0; i<(n_phys_regs - n_log_regs); i++){
			renamer::act_list.inst[i].complete = false;
			renamer::act_list.inst[i].exception = false;
		}	
		//PRF
		renamer::PRF = new unsigned long long[n_phys_regs];		
		//READY BITS
		renamer::PRF_RBA = new bool[n_phys_regs];
		for(unsigned int i=0;i<n_phys_regs;i++){
			renamer::PRF_RBA[i] = true;
			renamer::PRF[i] = 0;
		}

		// Initializing BRANCH CHECK POINT
		for(unsigned int i=0;i<renamer::maxBranches;i++){
			renamer::branch_chk_pt[i].cp_rmt = new int [n_log_regs];
			//renamer::branch_chk_pt[i].free=1;
		// did not initialize all values of all check point rmts
		}
		//GBM intialize
		GBM = 0;
	
	}
	
	
	void renamer::movePoint(unsigned int &point,unsigned int size,int pos){
			point = (point+pos)%size;
			return;	
	}
	
	
	bool renamer::stall_reg(unsigned int bundle_dst){
		//cout<<"stall_reg fl size"<<f_list.currSize<<endl;	
		return ((f_list.currSize < bundle_dst)?true:false);
	}


	bool renamer::stall_branch(unsigned int bundle_branch){
		unsigned int count=0;
		if(DEB)
		cout<<"stall_br"<<endl;	
		for(unsigned int i=0;i<maxBranches;i++){
			if( ( (GBM>>i) & 0x1UL ) == 0 )
				count++;
			if(count>=bundle_branch)
				break;
		}
		//assert(count>=bundle_branch && " stall br ");
		if(DEB)
		cout<<"stall br"<<endl;
		return (count < bundle_branch?true:false);
	}	

	unsigned long long renamer::get_branch_mask(){
	return GBM;
	}
	
	unsigned int renamer::rename_rsrc(unsigned int log_reg){
		if(DEB)
		cout<<"renamer_rsrc"<<endl;	
	return RMT[log_reg];
	}
	
	unsigned int renamer::rename_rdst(unsigned int log_reg){
		assert(f_list.currSize>0 && "No free regs to rename dst");
		f_list.currSize--;
		unsigned int renamedReg;
		renamedReg = f_list.ele[f_list.head]; // Get renamed regs name from FL
		if(DEB)
		cout<<"old head "<<f_list.head<<endl;
		renamer::movePoint(f_list.head,(totalPhyRegs - totalArchRegs),1); // Move the head to next location
		if(DEB)
		cout<<"new head "<<f_list.head<<endl;
		// Make PRF ready bit to 0
		//PRF_RBA[renamedReg]=0;
		RMT[log_reg]=renamedReg; // Making the entry in RMT
		if(DEB)
		cout<<"rename_dst"<<endl;	
	return renamedReg;
	}

	unsigned int renamer::findFirstZero(unsigned long long g){
		unsigned long long inv;
		unsigned long long comp;
		inv=~g;
		assert(g<0xffffffffffffffffULL && "GBM 0func is full");
		comp=g+1;
		unsigned int i; 
		i=(unsigned int)log2(comp&inv);
		if(DEB)
		cout<<"return pos in "<<i<<" gbm "<<hex<<GBM<<dec<< " i is "<<log2(comp&inv)<<endl;
		return i;
	}

	unsigned long long renamer::giveBrId(int pos){
		unsigned long long x;
		x=1;
		x=x<<pos;
		return (x); 
	}

	void  renamer::setGBM(int i){
		unsigned long long x;
		x=1;
		x=x<<i;
		GBM=GBM|x;
		if(DEB)
		cout<<"set GBM "<<hex<<GBM<<dec<<endl;
		return;
			
	}
		
	void  renamer::clearGBM(unsigned int i){
		unsigned long long x;
		x=1;
		x=x<<i;
		x=~x;
		GBM=GBM & x;
		if(DEB)
		cout<<"cleared gbm "<<hex<<GBM<<dec<<endl;
		return;			
	}
	
	unsigned int renamer::checkpoint(){
		assert(GBM<0xffffffffffffffffULL && "GBM is full");	
	// ERROR CHECK FOR MAX BRANCH INSTEAD
		unsigned int position = findFirstZero(GBM);
		setGBM(position);
		assert(position < maxBranches && " tryin to access wronf location in branch check pt");
		branch_chk_pt[position].gbm = GBM;
	//branch_chk_pt[position].free = 0;
		branch_chk_pt[position].fl_head = f_list.head;
		branch_chk_pt[position].fl_size = f_list.currSize;
		branch_chk_pt[position].al_size = act_list.currSize;
	// check for rmt deallocte
	//delete[] branch_chk_pt[position].cp_rmt;
	// re allocate
	//branch_chk_pt[position].cp_rmt = new int [totalArchRegs];
	//copy RMT
		for(unsigned int i=0; i<totalArchRegs ; i++)
			branch_chk_pt[position].cp_rmt[i] = RMT[i];
	// done !
		return position;	
	}	

	bool renamer::stall_dispatch(unsigned int bundle_inst){		
		return (act_list.currSize < bundle_inst?true:false);	
	}
	
	unsigned int renamer::dispatch_inst(bool dest_valid,
				   unsigned int log_reg,
				   unsigned int phys_reg,
				   bool load,
				   bool store,
				   bool branch,
				   unsigned int PC){
		
	if(DEB)
		cout<<"disp_inst"<<endl;	
	assert(act_list.currSize > 0 && " act list size error" );
	act_list.inst[act_list.tail].pc = PC;
	act_list.inst[act_list.tail].load =load;
	act_list.inst[act_list.tail].store =store;
	act_list.inst[act_list.tail].branch =branch;
	act_list.inst[act_list.tail].complete =false;
	act_list.inst[act_list.tail].exception =false;
	act_list.inst[act_list.tail].destFlag = dest_valid;
	//if(dest_valid){
		
		act_list.inst[act_list.tail].phyDestReg = phys_reg;
		act_list.inst[act_list.tail].logDestReg = log_reg;
	//}
	unsigned int retTail;
	retTail = act_list.tail;
	act_list.currSize--;
	renamer::movePoint(act_list.tail,totalPhyRegs - totalArchRegs,1);
	
	if(DEB)
		cout<<"Inst goes in "<<retTail<<" tail at "<<act_list.tail<<endl;
	
	return retTail;
	}

	bool renamer::is_ready(unsigned int phys_reg){
		if(DEB)
		cout<<"is_ready"<<endl;	
		return PRF_RBA[phys_reg];
	}

	/////////////////////////////////////////////////////////////////////
	// Clear the ready bit of the indicated physical register.
	/////////////////////////////////////////////////////////////////////
	void renamer::clear_ready(unsigned int phys_reg){
		PRF_RBA[phys_reg]=false;
	return;
	}	


	/////////////////////////////////////////////////////////////////////
	// Set the ready bit of the indicated physical register.
	/////////////////////////////////////////////////////////////////////
	void renamer::set_ready(unsigned int phys_reg){
		PRF_RBA[phys_reg]=true;
	return;
	}

	//////////////////////////////////////////
	// Functions related to Reg. Read Stage.//
	//////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////
	// Return the contents (value) of the indicated physical register.
	/////////////////////////////////////////////////////////////////////
	unsigned long long renamer::read(unsigned int phys_reg){
	if(DEB)
		cout<<" prf value "<<PRF[phys_reg]<<" at "<<phys_reg<<endl;
	return PRF[phys_reg];
	}

	//////////////////////////////////////////
	// Functions related to Writeback Stage.//
	//////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////
	// Write a value into the indicated physical register.
	/////////////////////////////////////////////////////////////////////
	void renamer::write(unsigned int phys_reg, unsigned long long value){
		if(DEB)
		cout<<"phy to write at "<<phys_reg<<" PRF SIZE "<<totalPhyRegs;
	//	assert(phys_reg < totalPhyRegs && "invalid phys reg to write");
		PRF[phys_reg] = value;
	return;
	}

	/////////////////////////////////////////////////////////////////////
	// Set the completed bit of the indicated entry in the Active List.
	/////////////////////////////////////////////////////////////////////
	void renamer::set_complete(unsigned int AL_index){
	act_list.inst[AL_index].complete = true;
	return;
	}
	
	void renamer::resolve(unsigned int AL_index,
		     unsigned int branch_ID,
		     bool correct){
	if(DEB)
	cout<<"resolve"<<endl;	
	// where in ALi
	//act_list.inst[AL_index]
	// check point
	if(correct){
		if(DEB)
		cout<<"correct pred - clear gbm"<< hex<<GBM<<dec<<endl;
		//clear branches bit in GBM
		clearGBM(branch_ID);
		//clear branches bit in all check points
		unsigned long long x; 
		for(int i=0; i<maxBranches;i++){
			x=1;
			x = x << branch_ID;
			x = ~x; 	
			branch_chk_pt[i].gbm = branch_chk_pt[i].gbm & x;
		}
	// ERROR ASSUMING THAT IF A BR IS CORRECT ALL PREV WERE CORRECT
	// what happens
	// this branch correct....prev branch was wrong
	// come to know latter
	// sqaush in 
	}else{
		if(DEB)
		cout<<"wrong pred - clear gbm"<< hex<<GBM<<dec<<endl;
	//recovery for mispredict
	// set global GBM	
		GBM = branch_chk_pt[branch_ID].gbm;
		//branch_chk_pt[branch_ID].free=0;
	// clear its bit in GBM
		clearGBM(branch_ID);
	//restore structures
	// Check for size of free list
		if(branch_chk_pt[branch_ID].fl_head != f_list.tail){
			f_list.currSize=0;
			while((branch_chk_pt[branch_ID].fl_head + f_list.currSize)%(totalPhyRegs-totalArchRegs) != f_list.tail){
				f_list.currSize++;
			}  
		}else{
			if(branch_chk_pt[branch_ID].fl_size == 0){
				f_list.currSize = 0;
				cout<<" Free list size 0 "<<endl;
			}else{
			f_list.currSize = (totalPhyRegs -totalArchRegs);}
		}
	// Head of free list now changed;	
		f_list.head = branch_chk_pt[branch_ID].fl_head;
	// RMT reverted
		memcpy(RMT,branch_chk_pt[branch_ID].cp_rmt,sizeof(unsigned int)*totalArchRegs);
	// Flush A L ??
	// Make the tail now point to next instruction after this in AL
		if(DEB)
		cout<<"in resolve - prev index"<<AL_index<<endl;
		/*if(branch_chk_pt[branch_ID].al_size == 0){
			cout<<" range of AL "<<totalPhyRegs - totalArchRegs<<endl;
			cout<<" br was at index "<<AL_index<<endl;
			cout<<" Active list size 0 at chk pt - now size "<<act_list.currSize<<" head "<<act_list.head<<" tail "<<act_list.tail<<endl;
		}*/
		movePoint(AL_index,totalPhyRegs -totalArchRegs,1);
		int size=0;

		while((AL_index + size)%(totalPhyRegs -totalArchRegs)!= act_list.tail){
			size++;
		}

		if(DEB)
		cout<<"in resolve - next index"<<AL_index<<endl;
		act_list.tail = AL_index;
		
		act_list.currSize = act_list.currSize + size;
		
		if(act_list.tail==act_list.head){
			//cout<<" AL chk pt size "<<branch_chk_pt[branch_ID].al_size<<endl;
			//cout<<" Assert "<<act_list.currSize<<" head "<<act_list.head<<" tail "<<act_list.tail<<endl;}
	}else {act_list.inst[AL_index].complete = false; }
	  }

	return;	
	}

	
	void renamer::commit(bool &committed, bool &load, bool &store, bool &branch,
		    bool &exception, unsigned int &offending_PC){
		if(DEB)
		cout<<"commit "<<endl;
	
	if(act_list.inst[act_list.head].complete==true && act_list.currSize != (totalPhyRegs - totalArchRegs)){
		
		if(act_list.inst[act_list.head].exception==true){
			
			committed=false;
			exception=true;
			if(DEB)
				cout<<"1"<<endl;
			offending_PC = act_list.inst[act_list.head].pc;
	
		}else{
			committed=true;
			exception=false;
			//offending_PC = act_list.inst[act_list.head].pc;
			if(DEB)
			cout<<"2"<<endl;
			
			load = act_list.inst[act_list.head].load;
			store = act_list.inst[act_list.head].store;
			branch = act_list.inst[act_list.head].branch;
		}
	}else{
			if(DEB)
			cout<<"3"<<endl;
		exception = false;
		committed = false;			
	}


	if(committed==false && exception==true){
	//restore rmt
	//memcpy(RMT,AMT,sizeof(unsigned int)*totalArchRegs);
		for(unsigned int i=0;i<totalArchRegs; i++){
			RMT[i]=AMT[i];
	//make corresponding prf rba high
		}
	
		for(unsigned int i=0; i<(totalPhyRegs);i++){
			PRF_RBA[i]=true;}
	// restore free list
		f_list.currSize = (totalPhyRegs - totalArchRegs);
		// change here
		f_list.head = f_list.tail ;
	//GBM		
		GBM=0;
	//do with other structs - empty pipeline
		act_list.currSize = totalPhyRegs - totalArchRegs;
		// changed here
		act_list.tail = act_list.head ;
		act_list.inst[act_list.head].complete=false;
		act_list.inst[act_list.head].exception=false;
	}
	if(committed==true){
		assert(act_list.currSize < (totalPhyRegs -totalArchRegs)&& "AL aready empty - error" );
		act_list.currSize++;
		
		if(act_list.inst[act_list.head].destFlag){
			f_list.currSize++;
			f_list.ele[f_list.tail]=AMT[act_list.inst[act_list.head].logDestReg];	
			renamer::movePoint(f_list.tail,(totalPhyRegs - totalArchRegs),1);
			// make al false
			AMT[act_list.inst[act_list.head].logDestReg] = act_list.inst[act_list.head].phyDestReg;	}
		
		renamer::movePoint(act_list.head,totalPhyRegs - totalArchRegs,1);
		if(act_list.head == act_list.tail){
			act_list.currSize = totalPhyRegs - totalArchRegs;
			//cout<<" gadbad hain bhai gadbad hain "<<act_list.currSize<<endl;
		}
		
		if(DEB)
		cout<<" acl size "<<act_list.currSize<<" tot "<<totalPhyRegs<<endl;		
		if(DEB)
		cout<<" acl head "<<act_list.head<<endl;		
		if(DEB)
		cout<<" acl tail "<<act_list.tail<<endl;		
	}
	//move head before goin
	//increment size before going	
	return;
	}

	//////////////////////////////////////////
	// Functions not tied to specific stage.//
	//////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////
	// Set the exception bit of the indicated entry in the Active List.
	/////////////////////////////////////////////////////////////////////
	void renamer::set_exception(unsigned int AL_index){
		act_list.inst[AL_index].exception = true;
	return;
	}





